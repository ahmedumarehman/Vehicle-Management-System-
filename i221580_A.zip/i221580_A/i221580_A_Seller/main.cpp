#include <iostream>
#include <fstream>
#include "used_cars.h"
#include "new_cars.h"
#include "bikes.h"

// Your main function and other code go here

int main() {
    // ...

    return 0;
}
